<?php
/**
 * all file includeed
 *
 * @param  
 * @return mixed|string
 */
	include( get_template_directory() . '/inc/define-template.php' );
	include( get_template_directory() . '/inc/custom-function.php' );
	// customizer
	include( get_template_directory() . '/inc/custom-customizer.php' );
	include( get_template_directory() . '/inc/customizer.php' );
