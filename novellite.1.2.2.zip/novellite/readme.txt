"NovelLite One Page Business WordPress Theme" By ThemeHunk.

== Theme: NovelLite ==

* By ThemeHunk, http://themehunk.com/

== Theme License & Copyright ==
NovelLite Theme is distributed under the terms of the GNU GPL
NovelLite Theme - Copyright 2014 NovelLite Theme, themehunk.com

License for images:
1. Image Name: slider1.jpg 
Resource link: https://www.pexels.com/photo/fashion-man-person-model-2887/
Licensed under the CCO license.
License link : https://www.pexels.com/photo-license/
2. Image Name: testimonial-back.jpg
Resource link: https://www.pexels.com/photo/dawn-nature-sunset-trees-2946/
Licensed under the CCO license.
License link : https://www.pexels.com/photo-license/
3. Image Name: contact-back.jpg
Resource link: https://www.pexels.com/photo/skyline-buildings-new-york-skyscrapers-2324/
Licensed under the CCO license.
License link : https://www.pexels.com/photo-license/

== Superfish Menu, superfish.js License & Copyright ==
Copyright 2013 jQuery Foundation and other contributors,
http://jquery.com

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION 
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
License Link: http://github.com/joeldbirch/superfish/blob/master/MIT-LICENSE.txt

== bootstrap.min.js ==
Bootstrap v3.1.0 (http://getbootstrap.com)
Copyright 2011-2015 Twitter, Inc.
Licensed under MIT: (https://github.com/twbs/bootstrap/blob/master/LICENSE)

== Font Awesome Icons==
Font Licensed under OFL  - http://fontawesome.io
License: SIL OFL 1.1
Code License - http://fortawesome.github.io/Font-Awesome/license/
License: MIT License
License URI: http://opensource.org/licenses/mit-license.html
Copyright: Dave Gandy http://fontawesome.io

Brand Icons
All brand icons are trademarks of their respective owners.
The use of these trademarks does not indicate endorsement of the trademark holder by Font Awesome, nor vice versa.

== Flex slider ==
* http://www.woothemes.com/flexslider/
* Licensed under the MIT license.: License http://opensource.org/licenses/MIT

== jquery.prettyPhoto.js ==
Class: prettyPhoto
	Use: Lightbox clone for jQuery
	Author: Stephane Caron (http://www.no-margin-for-errors.com)
	Version: 3.1.3
	Licensed Under GPLV2 license
http://www.gnu.org/licenses/gpl-2.0.html
	
==jquery.easing.1.3.js
Licensed under the BSD license

== animate.css
Licensed under the MIT license

== jquery.bxslider.css
Released under the MIT license

==jquery.superslides.js
Released under the MIT license

==hammer.min.js
Released under the MIT license

==jcarousellite_1.0.1.min.js
Copyright (c) 2006-2014 Ganeshji Marwaha

Permission is hereby granted, free of charge, to any person
obtaining a copy of this software and associated documentation
files (the "Software"), to deal in the Software without
restriction, including without limitation the rights to use,
copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.

== Open Sans Font ==
License URL: http://scripts.sil.org/OFL

==  Other Licenses ==
See headers of files for further details.
	
== Theme License & Copyright ==
NovelLite is distributed under the terms of the GNU GPL
NovelLite -Copyright 2013 NovelLite, ThemeHunk.com
custom.js, mobile-menu.js is distributed under the terms of the GNU GPL
License For js
    All js files are GPL Compatible.
    See headers of JS files for further details.

Once again, thank you so much for trying the NovelLite WordPress Theme. As we said at the beginning, we will be glad to help you. If you have any questions related to this theme then do let us know & we will try our best to assist. If you have any general questions related to the themes on ThemeHunk, we would recommend you to visit the ThemeHunk Support Forum and ask your queries there.